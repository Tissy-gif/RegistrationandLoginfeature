/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Login {
      private String username;
    private String password;

    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() > 5;
    }

    public boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 && password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*])[A-Za-z\\d!@#$%^&*]+$");
    }

    public String registerUser(String username, String password) {
        if (!checkUserName(username)) {
            return "Username is incorrect format";
        } else if (!checkPasswordComplexity(password)) {
            return "Password does not meet complexity requirements";
        } else {
            this.username = username;
            this.password = password;
            return "User registered successfully";
        }
    }

    public boolean loginUser(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }
 public String returnLoginStatus(boolean loginStatus) {
        if (loginStatus) {
            return "Login successful";
        } else {
            return "Login failed";
        }
    }

}
