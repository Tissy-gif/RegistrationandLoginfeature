/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.usernamecheck;

/**
 *
 * @author User
 */

import java.util.Scanner;

public class UsernameCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter username: ");
        String username = scanner.next();
        System.out.print("Enter password: ");
        String password = scanner.next();
        System.out.print("Enter first name: ");
        String firstName = scanner.next();
        System.out.print("Enter last name: ");
        String lastName = scanner.next();
        System.out.println(checkUsername(username, password, firstName, lastName));
    }

    public static String checkUsername(String username, String password, String firstName, String lastName) {
        if (username.length() <= 5 && username.contains("_")) {
            return "Username successfully captured";
        } else {
            return "Username is not correctly formatted, please ensure that your username conatins an underscore and is no more than 5 characters in length.";
        }
    }
    
    public static String checkPassword(String password) {
        if (password.length() >= 8 && password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*])[A-Za-z\\d!@#$%^&*]+$")) {
            return "Password successfully captured";
        } else {
            return "Password is not formatted correctly";
        }
    }

}


